import 'package:flutter/material.dart';
import 'views/login_page.dart';

void main() {
  runApp(const MaterialApp(
      debugShowCheckedModeBanner: false, title: 'Battleships', home: App()));
}
